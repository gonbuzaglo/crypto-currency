/// <reference path="jquery-3.4.1.js" />
$(document).ready(function () {
    getCoinsAsync(); // bring the coins
    initializePopOver(); // bs popover : for search settings feature 
    $('[data-toggle="tooltip"]').tooltip(); //bs tooltip 
});

function initializePopOver(){ // config popover
    $('[data-toggle="popover"]').popover({
        container: 'body',
        html: true,
        placement: 'bottom',
        sanitize: false,
        content: `<div id="PopoverContent">
            <div id="myRadioForm">
            <div class="form-check-inline">
            <label class="form-check-label">
              <input type="radio" class="form-check-input" name="optRadio" value="searchStrict" checked>Search strict
            </label>
          </div>
          <div class="form-check-inline">
            <label class="form-check-label">
              <input type="radio" class="form-check-input" id="tellToSearchUnStrict" name="optRadio" value="searchUnStrict">Search Unstrict
            </label>
          </div>        
            </div>
              <div class="input-group" id="valueTypes">
              <p style="margin-top:7px"><b>Value To Search By:</b></p>
              <select class="form-control" id="valueTypeToSearchBy">
              <option>Symbol</option>
              <option>Name</option>
            </select>
              </div>
            </div>`
    });
}

$('#openPopover').on('shown.bs.popover', function () { // events for popover
    initializeRadioSettings();

    initializeSelectSettings();
});

$(document).mouseup(function (e) { // when clicking outside popover, exit it.
    const container = $(".popover");

    if (!container.is(e.target) && container.has(e.target).length === 0) {
        container.popover("hide");
    }
});

let _radioVal = "searchStrict"; // on default search for whole values

function initializeRadioSettings() { // search can go for whole/partial values
    $('#myRadioForm').on('change', function () {
        _radioVal = $('input[name=optRadio]:checked', '#myRadioForm').val();
        if (_radioVal === 'searchStrict') {
            $('#valueTypes').show();
        } else if (_radioVal === 'searchUnStrict') {
            $('#valueTypes').hide();
        }
    });
}

let _valueTypeToSearchBy = "Symbol"; // on default search by symbol value

function initializeSelectSettings() { // search can go for synbol/name
    $('#valueTypeToSearchBy').on('change', function () {
        _valueTypeToSearchBy = $(this).val();
    });
}

$('#openPopover').click(() => { 
    // when reopen popover, config is called. html reset.
    // so we want that the values to be reset as well. that way the settings button can also reset the settings.
    _radioVal = "searchStrict";
    _valueTypeToSearchBy = "Symbol";
})

const _localStorageCoins = JSON.parse(localStorage.getItem('coins')) || []; // if already exists, update. if does not exist, create new array for localstorage.

async function getCoinsAsync() { // get data from localStorage/ajax call
    try {
        let coins;
        if (!localStorage.getItem("allCoins")) {
            coins = await getData("https://api.coingecko.com/api/v3/coins/list");
            localStorage.setItem('allCoins', JSON.stringify(coins));
        } else {
            coins = JSON.parse(localStorage.getItem("allCoins"));
        }
        fillCoinsContainer(coins);
    } catch (error) {
        alert(error.message);
    } finally {
        $('#currencySpinner').hide();
        $('#coins').show();
    }
}

function getData(url) {
    return new Promise((resolve, reject) => {
        $.getJSON(url, json => resolve(json)) // jquery ajax call
            .fail(err => reject(
                new Error("Status: " + err.status + ", Text: " + err.statusText)));
    });
}

function fillCoinsContainer(array) { // render dynamically the main page
    let str = "";
    for (let i = 0; i < 800; i++) {
        str += `<div class="card text-white bg-dark mb-3 coin-currency-card toggle-opacity" style="max-width: 18rem;" coinSymbol='${array[i].symbol}' coinId='${array[i].id}' coinName='${array[i].name}'>
                                            <div class="card-header">
                                                <h4 class="card-title"><p class="symbol-headline">${array[i].symbol}<p>                                   
                                                        <label class="switch">
                                                            <input type="checkbox" coinSymbol='${array[i].symbol}' coinId='${array[i].id}' class='toggleInput'>
                                                            <span class="slider round"></span>
                                                        </label>
                                                </h4>
                                            </div>
                                            <div class="card-body">
                                                <p class="card-text">${array[i].name}</p>
                                                <button type="button" class="btn btn-primary more-info-button" data-toggle="collapse" openFor="_${array[i].id}" data-target="#_${array[i].id}">More Info</button>
                                                <div id="_${array[i].id}" class="collapse more-info">
                                                    <div class="info-section" style="display:none"></div>
                                                    <div class='loadingMessage'>
                                                        <img src='./assets/photos/coolestSpinner.gif' height='70' width='70'/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                   `
    }
    $("#coins").html(str);
    defineHandlers(); // after rendering, add events
}

function defineHandlers() { // adding events to rendered main page
    bindInfoClick();

    bindToggleClick();
}

let _reportsList = []; // array to keep track on selected coins

function bindToggleClick() { // function handles toggle buttons and modal
    $(".toggleInput").click(function () {
        const symbol = $(this).attr("coinSymbol")
        const id = $(this).attr("coinId")
        if ($(this).is(':checked')) {
            $(`.coin-currency-card[coinSymbol="${symbol}"][coinId="${id}"]`).removeClass( "toggle-opacity" ).addClass( "coin-card-selected" );
            _reportsList.push(symbol);
            if (_reportsList.length > 5) {
                $('#modalTable').empty()
                _reportsList.forEach(function (symbol) {
                    $('#modalTable').append(`<tr coinSymbol='${symbol}'><th>${symbol}</th><td><i class="fa fa-trash" coinSymbol='${symbol}' coinId='${id}'></i></td></tr>`);
                })
                $('.fa-trash').on('click', function () {
                    _reportsList = _reportsList.filter(val => val != $(this).attr('coinSymbol'));
                    $(this).closest("tr").remove();
                    let mySymbol = $(this).attr('coinSymbol');
                    $(`.coin-currency-card[coinSymbol='${mySymbol}']`).removeClass( "coin-card-selected" ).addClass( "toggle-opacity" );
                    $(`input[coinSymbol="${mySymbol}"]`).prop("checked", false);
                });
                $('#myModal').modal('show');
            }
        } else {
            $(`.coin-currency-card[coinSymbol=${$(this).attr('coinSymbol')}][coinId=${$(this).attr('coinId')}]`).removeClass( "coin-card-selected" ).addClass( "toggle-opacity" );
            _reportsList = _reportsList.filter(val => val != symbol);
        }
    })
}

$('#modalReportsButton').on('click', function(){ // button inside modal, direct user to reports page
    $('#currenciesNav').removeClass('active');
    $('#reportsNav').addClass('active');
    $('#myModal').modal('hide');
    $("#chartContainer").empty();
    waitForChartsToLoad();
    createChart();
})

function bindInfoClick() { 
    $('.more-info-button').on('click', function () { 
        const id = $(this).attr('openFor').replace('_', ''); // id was defined in a specific way to allow bs to open collapse
        // now changed id back to be sent to server, used in arrays etc..
        const timeClicked = new Date().getTime(); // capture clicktime
        const toEnable = this; // pass the triggering button elment to next function
        $(this).prop("disabled", true); // prevent re-invoking the next function
        openDivAsync(id, timeClicked, toEnable);
        $(this).prop("disabled", false);
    });
}

async function openDivAsync(id, timeClicked, toEnable) {
    const div = $('#_' + id); // target div to collapse
    let indexOfMyId = _localStorageCoins.findIndex(x => x.id === id);
    if (indexOfMyId >= 0) { // if in localstorage
        let coinRetrieved = (_localStorageCoins).find(x => x.id === id);
        if (!timeIsOut(coinRetrieved.savedDate, timeClicked)) { // check that 2 minutes haven't passed since calling the API
            addToDiv(div, coinRetrieved.usd, coinRetrieved.ils, coinRetrieved.eur, coinRetrieved.img);
        } else { // if 2 min passed update in local storage and display new data from ajax in div
            _localStorageCoins.splice(indexOfMyId, 1);
            localStorage.setItem('coins', JSON.stringify(_localStorageCoins));
            reverseDiv(div);
            let calledCoin = await callMoreInfoAsync(id);
            $(toEnable).prop("disabled", false);
            addToDiv(div, calledCoin.usd, calledCoin.ils, calledCoin.eur, calledCoin.img);
        }
    } else { // if weren't ever in localstorage, just call it
        let calledCoin = await callMoreInfoAsync(id);
        $(toEnable).prop("disabled", false);
        addToDiv(div, calledCoin.usd, calledCoin.ils, calledCoin.eur, calledCoin.img);
    }
}

function timeIsOut(savedDate, timeClicked) { //function tests that 2 min haven't passed
    if (timeClicked < (savedDate + 2 * 60 * 1000)) {
        return false;
    } else {
        return true;
    }
}

function addToDiv(div, usd, ils, eur, img) {
    let infoString =
        `
            <h6>pricing: </h6>
            USD: ${usd}$<br>
            EUR: ${eur}€<br>
            ILS: ${ils}₪
        `;

    $('<img src="' + img + '">').on('load', function () { // make sure you don't remove spinner until image is ready as well
        let moreInfoSec = div.find('.info-section');
        moreInfoSec.html(infoString);
        $(this).width(70).height(70).prependTo(moreInfoSec);
        div.find('.loadingMessage').css('display', 'none');
        moreInfoSec.css('display', 'initial');
    });
}

function reverseDiv(div) { // deleting the collapse div content before inserting new content
    div.find('.info-section').empty();
    div.find('.info-section').css('display', 'none');
    div.find('.loadingMessage').css('display', 'initial');
}

async function callMoreInfoAsync(id) { // calling data for  more info div
    let coin = await getData("https://api.coingecko.com/api/v3/coins/" + id);
    let o = {};
    o.usd = coin.market_data.current_price.usd;
    o.eur = coin.market_data.current_price.eur;
    o.ils = coin.market_data.current_price.ils;
    o.img = coin.image.small;
    o.id = id;
    o.savedDate = new Date().getTime();
    _localStorageCoins.push(o);
    localStorage.setItem('coins', JSON.stringify(_localStorageCoins));
    return o;
}

$('.navbar-nav a').on('click', function () { // toggle clicked navbar link when clicking one of them
    $('.navbar-nav').find('a.active').removeClass('active');
    $(this).addClass('active');
});

$('#currenciesNav').on('click', function () {
    if(_intervalReportsIsRunning = true){ // only if is still running
        clearInterval(_loadByInterval); // stop updating reports
    }
    $('#about, #reports').hide(); // change page display
    $('#currencies').show();
})

$('#aboutNav').on('click', function () {
    if(_intervalReportsIsRunning = true){ // only if is still running
        clearInterval(_loadByInterval); // stop updating reports
    }
    $('#currencies, #reports').hide(); // change page display
    $('#about').show();
})

// reports page

$('#reportsNav').on('click', function () { 
    if (_reportsList.length === 0) { // don't go to reports if haven't selected coins
        alert("please choose at least one coin for the reports, else we can't display them");
        $('#about, #reports').hide();
        $('#currencies').show();
        $('#reportsNav').removeClass('active');
        $('#currenciesNav').addClass('active');
    } else {
        $('#currenciesNav').removeClass('active');
        $('#reportsNav').addClass('active');
        $("#chartContainer").empty();
        waitForChartsToLoad();
        createChart();
    }
})

function waitForChartsToLoad() { // display spinner while rendering chart
    $('#chartContainer').hide();
    $('#onWait').show();
    setTimeout(() => {
        $('#onWait').hide();
        $('#chartContainer').show();
    }, 4000)
}

let _loadByInterval; //define the interval updating the chard in global scope so we eill be able to use refer it wherever we want
let _onChartCreation; //bool to determine if that's the first time I run the getChartCurrenciesObjectArrAsync.

function createChart() {
    _onChartCreation = true; // this function runs only on first time, so here we set the global variable to true
    const setUpOptions = CreateChartSetup();
    $("#chartContainer").CanvasJSChart(setUpOptions);
    for (const symbol of _reportsList) {
        setUpOptions.data.push({ // overall settings
            type: "line",
            xValueType: "dateTime",
            yValueFormatString: "###.00$",
            xValueFormatString: "hh:mm:ss TT",
            showInLegend: true,
            name: symbol.toUpperCase(),
            dataPoints: []
        })
    }
    $('#about, #currencies').hide();
    $('#reports').show();
    // call the update every 2000 millieseconds
    _loadByInterval = setInterval(function () {
        if(_reportsList.length !== 0){
            updateChartAsync();
            _intervalReportsIsRunning = true;
        } else {
            clearInterval(_loadByInterval);
            _intervalReportsIsRunning = false;
        }
    }, 2000);
}

let _intervalReportsIsRunning; // global boolean used to keep track if interval updating chart is running

const getChartCurrenciesObjectArrAsync = async function () {
    const currencySymbolString = (_reportsList.map(e => e.toUpperCase())).join(','); // make array of selected coins useable for 3rd api format
    const reports = await getData(`https://min-api.cryptocompare.com/data/pricemulti?fsyms=${currencySymbolString}&tsyms=USD`); // ajax call to 3rd api
    let result = [];
    if (reports.Message) {
        clearInterval(_loadByInterval);
        alert('none of selected coins have available chart data');
        $('#about, #reports').hide();
        $('#currencies').show();
        $('#reportsNav').removeClass('active');
        $('#currenciesNav').addClass('active');
    } else {
        for (const key in reports) {
            result.push({
                symbol: key,
                xValue: new Date().getTime(),
                yValue: reports[key].USD
            })
        }
        if(_onChartCreation && result.length < _reportsList.length){
            alert('some of the selected coins have no charts at the moment. all coins selected will appear in the header, but graphs will be drawn for available coins only.' )
            _onChartCreation = !_onChartCreation;
        }
        return result;
    }
}

function toggleDataSeries(e) {
    if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
        e.dataSeries.visible = false;
    } else {
        e.dataSeries.visible = true;
    }
    e.chart.render();
}


function CreateChartSetup() {
    return {
        zoomEnabled: true,
        animationEnabled: true,
        title: {
            text: _reportsList.map(e => e.toUpperCase()).join(', ') + ' Currency Value By USD. Try Zooming - Panning'
        },
        axisX: {
            title: "chart updates every 2 secs",
            valueFormatString: "hh:mm:ss tt"
        },
        axisY: {
            suffix: "$",
            includeZero: false
        },
        toolTip: {
            shared: true
        },
        legend: {
            cursor: "pointer",
            verticalAlign: "top",
            fontSize: 22,
            fontColor: "dimGrey",
            itemclick: toggleDataSeries
        },
        data: []
    }
}


async function updateChartAsync() { //giving the charts their current data
    const chart = $("#chartContainer").CanvasJSChart();
    currencieArray = await getChartCurrenciesObjectArrAsync();
    for (const updateObj of currencieArray) {
        for (const chartObj of chart.options.data) {
            if (updateObj.symbol === chartObj.name) {
                chartObj.dataPoints.push({
                    x: updateObj.xValue,
                    y: updateObj.yValue
                });
                chartObj.legendText = `${updateObj.symbol}:${updateObj.yValue}$`
            }
        }
    }
    chart.render(); 
}

$('#showSuccess').on('click', function () { //button to show only selected coins
    if ($(":checkbox:checked").length === 0) {
        alert('There are no selected coins')
    } else {
        $('#coins').hide();
        $('#currencySpinner').show();
        $('#about, #reports').hide(); // change page display
        $('#currencies').show();
        $('#reportsNav, #aboutNav').removeClass('active');
        $('#currenciesNav').addClass('active');
        setTimeout(function () {
            $('.coin-currency-card').each((i, c) => $(c).hide())
            $(":checkbox:checked").each((i, t) => {
                $(`.coin-currency-card[coinSymbol=${$(t).attr('coinSymbol')}][coinId=${$(t).attr('coinId')}]`).show();
            });
            $('#currencySpinner').hide();
            $('#coins').show();
        }, 0.0)
    }
});

$('#showAllCoins').click(function () { // function to display all the coins 
    $('#coins').hide();
    $('#currencySpinner').show();
    $('#about, #reports').hide(); // change page display
    $('#currencies').show();
    $('#reportsNav, #aboutNav').removeClass('active');
    $('#currenciesNav').addClass('active');
    setTimeout(function () {
        $('.coin-currency-card').each((i, c) => {
            $(c).show()
        });
        $('#currencySpinner').hide();
        $('#coins').show();
    }, 0.0)
});

$('#mySearchButton').click(function () { // calling the search function on button click
    if($('#mySearchInput').val() !== ''){
        searchCoin();
    }
})

$('#mySearchInput').keypress(function (e) { // calling the search function on enter key press
    var key = e.which;
    if (key == 13) // the enter key code
    {
        searchCoin();
        return false;
    }
});

function searchCoin() { //search function
    $('#coins').hide();
    $('#currencySpinner').show();
    $('#about, #reports').hide(); // change page display
    $('#currencies').show();
    $('#reportsNav, #aboutNav').removeClass('active');
    $('#currenciesNav').addClass('active');
    setTimeout(function () {
        let coinsHidden = 0;
        let allCoinCards = 0;
        $('.coin-currency-card').each((i, c) => $(c).show())
        $('.coin-currency-card').each((i, c) => {
            allCoinCards = i + 1;
            if (notFound(c)) {
                $(c).hide();
                coinsHidden++;
            }
        })
        if(_radioVal === 'searchUnStrict'){
            const myWord = $('#mySearchInput').val();
            highlight(myWord);
        }
        if (coinsHidden === allCoinCards) {
            alert("Illegal value. check your search settings please");
            $('.coin-currency-card').each((i, c) => $(c).show())
        } else if (coinsHidden !== allCoinCards) {
            $('#about, #reports').hide();
            $('#currencies').show();
            window.location.href = "#currencies";
        }
        $('#currencySpinner').hide();
        $('#coins').show();
    }, 0.0)
}

function notFound(c) { // adjust to search settings
    if (_radioVal === 'searchUnStrict') {
        return $(c).attr(`coinSymbol`).includes($('#mySearchInput').val().toLowerCase()) === false &&
            $(c).attr(`coinName`).includes($('#mySearchInput').val().toLowerCase()) === false
    } else if (_radioVal === 'searchStrict') {
        return $('#mySearchInput').val().toLowerCase() !== $(c).attr(`coin${_valueTypeToSearchBy}`).toLowerCase();
    }
}

function highlight(word) { //marker all found words/letters when searching unstrict
    $('.symbol-headline, .card-text').each((i, e)=> {
        const rgxp = new RegExp(word, 'g'); // search globally
        const repl = '<span class="highlight">' + word + '</span>'; // marker it!
       $(e).html($(e).text().replace(rgxp, repl)); // replace the title (symbol) and text (name) matched characters with markered char
    });
    $(document).one('click', () => { // first time after markering, clicking where on the document' cancel marker
        $('.symbol-headline > span, .card-text > span').each((i, e)=> {
           $(e).removeClass('highlight');
        });
    });
}
